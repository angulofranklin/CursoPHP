<HTML LANG="es">

<HEAD>
   <TITLE>Conversor de monedas</TITLE>
</HEAD>

<BODY>

<H1>Conversor de monedas</H1>

<FORM ACTION="practica5b-resultados.php" METHOD="POST">

<P>Cantidad en euros:
<INPUT TYPE="TEXT" NAME="euros">
Convertir a:
<SELECT NAME="moneda">
   <OPTION VALUE="d�lares" SELECTED>D�lares USA
   <OPTION VALUE="libras">Libras esterlinas
   <OPTION VALUE="yenes">Yenes japoneses
   <OPTION VALUE="francos">Francos suizos
</SELECT></P>

<INPUT TYPE="SUBMIT" NAME="enviar" VALUE="convertir">

</FORM>

</BODY>
</HTML>
