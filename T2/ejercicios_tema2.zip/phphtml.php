<HTML LANG="ES">

<HEAD>
   <TITLE>PHP y HTML</TITLE>
   <LINK REL="stylesheet" TYPE="text/css" HREF="estilo.css">
</HEAD>

<BODY>

<H1>PHP y HTML</H1>

<P>�ste es el p�rrafo 1, escrito desde HTML</P>

<?PHP
   print ("<P>�ste es el p�rrafo 2, escrito desde PHP</P>\n");
?>

<P>�ste es el p�rrafo 3, escrito nuevamente desde HTML</P>

<?PHP
   print ("<P>Y �ste es el p�rrafo 4, escrito desde PHP</P>\n");
?>

</BODY>
</HTML>
