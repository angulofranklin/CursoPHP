<HTML LANG="es">

<HEAD>
   <TITLE>Gr�fico de tarta</TITLE>
   <LINK REL="stylesheet" TYPE="text/css" HREF="estilo.css">
</HEAD>

<BODY>

<H1>Gr�fico de tarta</H1>

<P>Esta imagen ha sido creada desde PHP:</P>
<IMG SRC="crea_imagen.php" ALT="Gr�fico de tarta">

</BODY>
</HTML>
