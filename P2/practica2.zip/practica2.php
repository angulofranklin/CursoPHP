<HTML LANG="es">
<HEAD>
   <TITLE>Pr�ctica 2</TITLE>
</HEAD>

<BODY>

<?PHP
   print ("<H1>Pr�ctica 2</H1>\n");
   print ("<P>Este c�digo HTML ha sido generado mediante\n");
   print ("   instrucciones escritas en lenguaje PHP.</P>\n");
   print ("<HR>\n\n");
?>

</BODY>
</HTML>

