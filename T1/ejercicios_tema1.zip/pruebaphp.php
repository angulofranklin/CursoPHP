<?PHP
   phpinfo();
?>
