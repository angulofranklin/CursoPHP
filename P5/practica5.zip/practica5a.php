<HTML LANG="es">

<HEAD>
   <TITLE>Conversor de euros a pesetas</TITLE>
</HEAD>

<BODY>

<H1>Conversor de euros a pesetas</H1>

<FORM ACTION="practica5a-resultados.php" METHOD="POST">

<P>Cantidad en euros:
<INPUT TYPE="TEXT" NAME="euros" SIZE="10">
<INPUT TYPE="SUBMIT" NAME="enviar" VALUE="convertir"></P>

</FORM>

</BODY>
</HTML>
